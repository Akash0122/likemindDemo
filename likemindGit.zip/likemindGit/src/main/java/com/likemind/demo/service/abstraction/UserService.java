package com.likemind.demo.service.abstraction;

import com.likemind.demo.dto.*;
import com.likemind.demo.model.User;

import java.util.List;

/**
 * The interface User service.
 */
public interface UserService {

    /**
     * Add user boolean.
     *
     * @param addUserRequest the add user request
     * @return the boolean
     */
    boolean addUser(AddUserRequest addUserRequest);

    /**
     * Add topic boolean.
     *
     * @param addTopicRequest the add topic request
     * @return the boolean
     */
    boolean addTopic(AddTopicRequest addTopicRequest);

    /**
     * Subscribe topic boolean.
     *
     * @param subscribeTopicRequest the subscribe topic request
     * @return the boolean
     */
    boolean subscribeTopic(SubscribeTopicRequest subscribeTopicRequest);

    /**
     * Process message list.
     *
     * @return the list
     */
    List<MessageResponse> processMessage();

    boolean addMessage(AddMessageRequest addMessageRequest);

}
