package com.likemind.demo.dto;

public class AddMessageRequest {

    private String topicName;
    private String text;

    public AddMessageRequest(String topicName, String text) {
        this.topicName = topicName;
        this.text = text;
    }

    public AddMessageRequest() {
    }

    public String getTopicName() {
        return topicName;
    }

    public AddMessageRequest setTopicName(String topicName) {
        this.topicName = topicName;
        return this;
    }

    public String getText() {
        return text;
    }

    public AddMessageRequest setText(String text) {
        this.text = text;
        return this;
    }

    @Override
    public String toString() {
        return "AddMessageRequest{" +
                "topicName='" + topicName + '\'' +
                ", text='" + text + '\'' +
                '}';
    }
}
