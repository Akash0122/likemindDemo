package com.likemind.demo.model;

/**
 * The type Topic.
 */
public class Topic {

    private Integer topicId;
    private String topicName;

    /**
     * Instantiates a new Topic.
     *
     * @param topicId   the topic id
     * @param topicName the topic name
     */
    public Topic(Integer topicId, String topicName) {
        this.topicId = topicId;
        this.topicName = topicName;
    }

    /**
     * Instantiates a new Topic.
     */
    public Topic() {
    }

    /**
     * Gets topic id.
     *
     * @return the topic id
     */
    public Integer getTopicId() {
        return topicId;
    }

    /**
     * Sets topic id.
     *
     * @param topicId the topic id
     * @return the topic id
     */
    public Topic setTopicId(Integer topicId) {
        this.topicId = topicId;
        return this;
    }

    /**
     * Gets topic name.
     *
     * @return the topic name
     */
    public String getTopicName() {
        return topicName;
    }

    /**
     * Sets topic name.
     *
     * @param topicName the topic name
     * @return the topic name
     */
    public Topic setTopicName(String topicName) {
        this.topicName = topicName;
        return this;
    }

    @Override
    public String toString() {
        return "Topic{" +
                "topicId=" + topicId +
                ", topicName='" + topicName + '\'' +
                '}';
    }
}
