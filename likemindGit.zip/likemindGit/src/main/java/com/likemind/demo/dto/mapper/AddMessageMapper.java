package com.likemind.demo.dto.mapper;

import com.likemind.demo.dto.AddMessageRequest;
import com.likemind.demo.model.Message;

public final class AddMessageMapper {

    private static int count;

    public static Message addMessageMapper(AddMessageRequest addMessageRequest){

        count=count+1;
        Message message = new Message();
        message.setMessageId(count)
                .setText(addMessageRequest.getText())
                .setTopicName(addMessageRequest.getTopicName());
        return message;
    }
}
