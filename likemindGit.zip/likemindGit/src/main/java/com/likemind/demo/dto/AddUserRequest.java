package com.likemind.demo.dto;

import com.sun.istack.internal.NotNull;
import org.springframework.lang.NonNull;

/**
 * The type Add user request.
 */
public class AddUserRequest {

    @NotNull
    private String username;
    @NotNull
    private String role;

    /**
     * Instantiates a new Add user request.
     *
     * @param username the username
     * @param role     the role
     */
    public AddUserRequest(String username, String role) {
        this.username = username;
        this.role = role;
    }

    /**
     * Instantiates a new Add user request.
     */
    public AddUserRequest() {
    }

    /**
     * Gets username.
     *
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * Sets username.
     *
     * @param username the username
     * @return the username
     */
    public AddUserRequest setUsername(String username) {
        this.username = username;
        return this;
    }

    /**
     * Gets role.
     *
     * @return the role
     */
    public String getRole() {
        return role;
    }

    /**
     * Sets role.
     *
     * @param role the role
     * @return the role
     */
    public AddUserRequest setRole(String role) {
        this.role = role;
        return this;
    }

    @Override
    public String toString() {
        return "AddUserRequest{" +
                "username='" + username + '\'' +
                ", role='" + role + '\'' +
                '}';
    }
}
