package com.likemind.demo.dto.mapper;

import com.likemind.demo.dto.AddTopicRequest;
import com.likemind.demo.model.Topic;

/**
 * The type Topic mapper.
 */
public final class TopicMapper {

    private static int count;

    /**
     * Topi mapper topic.
     *
     * @param addTopicRequest the add topic request
     * @return the topic
     */
    public static Topic TopiMapper(AddTopicRequest addTopicRequest){

        count=count+1;
        Topic topic = new Topic();
        topic.setTopicId(count).setTopicName(addTopicRequest.getTopicName());
        return topic;
    }
}
