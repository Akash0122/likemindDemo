package com.likemind.demo.model;

public class Message {

    private Integer messageId;
    private String topicName;
    private String text;

    public Message(Integer messageId, String topicName, String text) {
        this.messageId = messageId;
        this.topicName = topicName;
        this.text = text;
    }

    public Message() {
    }

    public Integer getMessageId() {
        return messageId;
    }

    public Message setMessageId(Integer messageId) {
        this.messageId = messageId;
        return this;
    }

    public String getTopicName() {
        return topicName;
    }

    public Message setTopicName(String topicName) {
        this.topicName = topicName;
        return this;
    }

    public String getText() {
        return text;
    }

    public Message setText(String text) {
        this.text = text;
        return this;
    }
}
