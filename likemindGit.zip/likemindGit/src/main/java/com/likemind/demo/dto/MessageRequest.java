package com.likemind.demo.dto;

/**
 * The type Message request.
 */
public class MessageRequest {

    private Integer id;
    private String topicName;
    private String text;

    /**
     * Instantiates a new Message request.
     *
     * @param id        the id
     * @param topicName the topic name
     * @param text      the text
     */
    public MessageRequest(Integer id, String topicName, String text) {
        this.id = id;
        this.topicName = topicName;
        this.text = text;
    }

    /**
     * Instantiates a new Message request.
     */
    public MessageRequest() {
    }

    /**
     * Gets id.
     *
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * Sets id.
     *
     * @param id the id
     * @return the id
     */
    public MessageRequest setId(Integer id) {
        this.id = id;
        return this;
    }

    /**
     * Gets topic name.
     *
     * @return the topic name
     */
    public String getTopicName() {
        return topicName;
    }

    /**
     * Sets topic name.
     *
     * @param topicName the topic name
     * @return the topic name
     */
    public MessageRequest setTopicName(String topicName) {
        this.topicName = topicName;
        return this;
    }

    /**
     * Gets text.
     *
     * @return the text
     */
    public String getText() {
        return text;
    }

    /**
     * Sets text.
     *
     * @param text the text
     * @return the text
     */
    public MessageRequest setText(String text) {
        this.text = text;
        return this;
    }

    @Override
    public String toString() {
        return "MessageRequest{" +
                "id=" + id +
                ", topicName='" + topicName + '\'' +
                ", text='" + text + '\'' +
                '}';
    }
}
