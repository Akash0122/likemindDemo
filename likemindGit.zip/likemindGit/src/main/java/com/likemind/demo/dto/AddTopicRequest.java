package com.likemind.demo.dto;

/**
 * The type Add topic request.
 */
public class AddTopicRequest {

    private String topicName;
    private String userName;

    /**
     * Instantiates a new Add topic request.
     *
     * @param topicName the topic name
     * @param userName  the user name
     */
    public AddTopicRequest(String topicName, String userName) {
        this.topicName = topicName;
        this.userName = userName;
    }

    /**
     * Instantiates a new Add topic request.
     */
    public AddTopicRequest() {
    }

    /**
     * Gets topic name.
     *
     * @return the topic name
     */
    public String getTopicName() {
        return topicName;
    }

    /**
     * Sets topic name.
     *
     * @param topicName the topic name
     * @return the topic name
     */
    public AddTopicRequest setTopicName(String topicName) {
        this.topicName = topicName;
        return this;
    }

    /**
     * Gets user name.
     *
     * @return the user name
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets user name.
     *
     * @param userName the user name
     * @return the user name
     */
    public AddTopicRequest setUserName(String userName) {
        this.userName = userName;
        return this;
    }

    @Override
    public String toString() {
        return "AddTopicRequest{" +
                "topicName='" + topicName + '\'' +
                ", userName='" + userName + '\'' +
                '}';
    }
}
