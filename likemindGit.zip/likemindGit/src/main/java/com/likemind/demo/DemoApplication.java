package com.likemind.demo;

import com.likemind.demo.dto.*;
import com.likemind.demo.model.Role;
import com.likemind.demo.service.abstraction.UserService;
import com.likemind.demo.service.implementation.UserServiceImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static com.likemind.demo.constant.Command.*;

/**
 * The type Demo application.
 */
@SpringBootApplication
public class DemoApplication {

	/**
	 * The entry point of application.
	 *
	 * @param args the input arguments
	 */
	public static void main(String[] args) {
		UserService userService = new UserServiceImp();
		List<Role> roles = new ArrayList<>();
		SpringApplication.run(DemoApplication.class, args);
		roles.add(new Role().setRoleName("ADMIN").setRoleId(1));
		roles.add(new Role().setRoleId(2).setRoleName("USER"));

		Scanner scan = new Scanner(System.in);

		int count=1;
		while (count>0) {
			System.out.println("===Enter Command===");
			String command = scan.nextLine();
			switch (command) {
				case ADD_USER: {
					System.out.println("Enter Username And Role Of User");
					String username = scan.nextLine();
					String role = scan.nextLine();
					AddUserRequest addUserRequest = new AddUserRequest(username, role);
					System.out.println(userService.addUser(addUserRequest));
					break;
				}
				case ADD_TOPIC: {
					System.out.println("==Enter TopicName and UserName==");
					String topicName = scan.nextLine();
					String userName = scan.nextLine();
					AddTopicRequest addTopicRequest = new AddTopicRequest(topicName, userName);
					System.out.println(userService.addTopic(addTopicRequest));
					break;
				}
				case SUBSCRIBE_TOPIC: {
					System.out.println("==Please Enter TopicName And Username==");
					String topicName = scan.nextLine();
					String username = scan.nextLine();
					SubscribeTopicRequest subscribeTopicRequest = new SubscribeTopicRequest(topicName, username);
					System.out.println(userService.subscribeTopic(subscribeTopicRequest));
					break;

				}
				case ADD_MESSAGE:{
					System.out.println("==For Add Message Please Enter Topic Name and Text");
					String topicName = scan.nextLine();
					String text = scan.nextLine();
					AddMessageRequest addMessageRequest = new AddMessageRequest(topicName,text);
					System.out.println(userService.addMessage(addMessageRequest));
					break;
				}
				case PROCESS_MESSAGE: {
					System.out.println(userService.processMessage());
					break;

				}
				case END:{
					count=0;
					System.out.println("End Of Command System");
					break;
				}
				default: {
					System.out.println("please Enter Valid command");
					break;
				}
			}

		}
	}

}
