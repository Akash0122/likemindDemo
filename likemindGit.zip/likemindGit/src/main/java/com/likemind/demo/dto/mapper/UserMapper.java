package com.likemind.demo.dto.mapper;

import com.likemind.demo.dto.AddUserRequest;
import com.likemind.demo.model.User;

/**
 * The type User mapper.
 */
public final class UserMapper {

    private static int count;

    /**
     * User mapper user.
     *
     * @param addUserRequest the add user request
     * @return the user
     */
    public static User UserMapper(AddUserRequest addUserRequest){
        User user = new User();
        count=count+1;
        user.setRole(addUserRequest.getRole())
                .setUserId(count)
                .setUsername(addUserRequest.getUsername());
        return user;
    }
}
