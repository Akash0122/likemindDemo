package com.likemind.demo.model;

/**
 * The type Role.
 */
public class Role {

    private Integer roleId;
    private String roleName;

    /**
     * Instantiates a new Role.
     *
     * @param roleId   the role id
     * @param roleName the role name
     */
    public Role(Integer roleId, String roleName) {
        this.roleId = roleId;
        this.roleName = roleName;
    }

    /**
     * Instantiates a new Role.
     */
    public Role() {
    }

    /**
     * Gets role id.
     *
     * @return the role id
     */
    public Integer getRoleId() {
        return roleId;
    }

    /**
     * Sets role id.
     *
     * @param roleId the role id
     * @return the role id
     */
    public Role setRoleId(Integer roleId) {
        this.roleId = roleId;
        return this;
    }

    /**
     * Gets role name.
     *
     * @return the role name
     */
    public String getRoleName() {
        return roleName;
    }

    /**
     * Sets role name.
     *
     * @param roleName the role name
     * @return the role name
     */
    public Role setRoleName(String roleName) {
        this.roleName = roleName;
        return this;
    }

    @Override
    public String toString() {
        return "Role{" +
                "roleId=" + roleId +
                ", roleName='" + roleName + '\'' +
                '}';
    }
}
