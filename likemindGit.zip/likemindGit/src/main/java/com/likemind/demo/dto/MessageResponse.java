package com.likemind.demo.dto;

import com.likemind.demo.model.User;

/**
 * The type Message response.
 */
public class MessageResponse {

    private String topic;
    private String message;
    private User sendTo;

    /**
     * Instantiates a new Message response.
     *
     * @param topic   the topic
     * @param message the message
     * @param sendTo  the send to
     */
    public MessageResponse(String topic, String message, User sendTo) {
        this.topic = topic;
        this.message = message;
        this.sendTo = sendTo;
    }

    /**
     * Instantiates a new Message response.
     */
    public MessageResponse() {
    }

    /**
     * Gets topic.
     *
     * @return the topic
     */
    public String getTopic() {
        return topic;
    }

    /**
     * Sets topic.
     *
     * @param topic the topic
     * @return the topic
     */
    public MessageResponse setTopic(String topic) {
        this.topic = topic;
        return this;
    }

    /**
     * Gets message.
     *
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets message.
     *
     * @param message the message
     * @return the message
     */
    public MessageResponse setMessage(String message) {
        this.message = message;
        return this;
    }

    /**
     * Gets send to.
     *
     * @return the send to
     */
    public User getSendTo() {
        return sendTo;
    }

    /**
     * Sets send to.
     *
     * @param sendTo the send to
     * @return the send to
     */
    public MessageResponse setSendTo(User sendTo) {
        this.sendTo = sendTo;
        return this;
    }

    @Override
    public String toString() {
        return "MessageResponse{" +
                "topic='" + topic + '\'' +
                ", message='" + message + '\'' +
                ", sendTo=" + sendTo +
                '}';
    }
}
