package com.likemind.demo.service.implementation;

import com.likemind.demo.dto.*;
import com.likemind.demo.dto.mapper.AddMessageMapper;
import com.likemind.demo.dto.mapper.TopicMapper;
import com.likemind.demo.dto.mapper.UserMapper;
import com.likemind.demo.model.Message;
import com.likemind.demo.model.Topic;
import com.likemind.demo.model.User;
import com.likemind.demo.service.abstraction.UserService;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * The type User service imp.
 */
@Service
public class UserServiceImp implements UserService {

    /**
     * The Users.
     */
    List<User> users = new ArrayList<>();
    /**
     * The User map.
     */
    Map<String, User> userMap = new HashMap<>();
    /**
     * The Topics.
     */
    List<Topic> topics = new ArrayList<>();
    /**
     * The Topic map.
     */
    Map<String, Topic> topicMap = new HashMap<>();
    /**
     * The Topic name and users map.
     */
    Map<String, List<User>> topicNameAndUsersMap = new HashMap<>();
    /**
     * The Username and topics map.
     */
    Map<String, List<Topic>> usernameAndTopicsMap = new HashMap<>();

    List<Message> messages = new ArrayList<>();
    Map<String, Message> topicNameAndMessageMap = new HashMap<>();


    @Override
    public boolean addUser(AddUserRequest addUserRequest) {
        User user = UserMapper.UserMapper(addUserRequest);
        users.add(user);
        userMap.put(user.getUsername(), user);
        return true;
    }

    @Override
    public boolean addTopic(AddTopicRequest addTopicRequest) {
        User user = userMap.get(addTopicRequest.getUserName());
        if (Objects.isNull(user) || !(user.getRole().equals("ADMIN"))) {
            return false;
        }
        Topic topic = TopicMapper.TopiMapper(addTopicRequest);
        topics.add(topic);
        topicMap.put(topic.getTopicName(), topic);
        return true;
    }

    @Override
    public boolean subscribeTopic(SubscribeTopicRequest subscribeTopicRequest) {

        User user = userMap.get(subscribeTopicRequest.getUsername());
        Topic topic = topicMap.get(subscribeTopicRequest.getTopicName());
        if (Objects.isNull(user) || Objects.isNull(topic)) {
            return false;
        }
        if (usernameAndTopicsMap.containsKey(user.getUsername())) {
            List<Topic> topics = usernameAndTopicsMap.get(user.getUsername());
            topics.add(topic);
            usernameAndTopicsMap.put(user.getUsername(), topics);
        } else {
            usernameAndTopicsMap.put(user.getUsername(), Collections.singletonList(topic));
        }
        if (topicNameAndUsersMap.containsKey(topic.getTopicName())) {
            List<User> users = topicNameAndUsersMap.get(topic.getTopicName());
            users.add(user);
            topicNameAndUsersMap.put(topic.getTopicName(), users);
        } else {
            topicNameAndUsersMap.put(topic.getTopicName(), Collections.singletonList(user));
        }
        return true;
    }

    @Override
    public List<MessageResponse> processMessage() {
        List<MessageResponse> responses = new ArrayList<>();
        for (Message message : messages) {
            String topicName = message.getTopicName();
            String msg = message.getText();
            List<User> users = topicNameAndUsersMap.get(topicName);
            if (!Objects.isNull(users)) {
                for (User user : users) {
                    MessageResponse messageResponse = new MessageResponse();
                    messageResponse.setMessage(msg)
                            .setSendTo(user)
                            .setTopic(topicName);
                    responses.add(messageResponse);
                }
            }
        }

        return responses;
    }

    @Override
    public boolean addMessage(AddMessageRequest addMessageRequest) {

        String topicName = addMessageRequest.getTopicName();
        if (!topicMap.containsKey(topicName)) {
            return false;
        }
        Message message = AddMessageMapper.addMessageMapper(addMessageRequest);

        topicNameAndMessageMap.put(message.getTopicName(), message);
        messages.add(message);
        return true;
    }


}
