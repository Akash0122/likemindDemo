package com.likemind.demo.dto;

/**
 * The type Subscribe topic request.
 */
public class SubscribeTopicRequest {

    private String topicName;
    private String username;

    /**
     * Instantiates a new Subscribe topic request.
     *
     * @param topicName the topic name
     * @param username  the username
     */
    public SubscribeTopicRequest(String topicName, String username) {
        this.topicName = topicName;
        this.username = username;
    }

    /**
     * Instantiates a new Subscribe topic request.
     */
    public SubscribeTopicRequest() {
    }

    /**
     * Gets topic name.
     *
     * @return the topic name
     */
    public String getTopicName() {
        return topicName;
    }

    /**
     * Sets topic name.
     *
     * @param topicName the topic name
     */
    public void setTopicName(String topicName) {
        this.topicName = topicName;
    }

    /**
     * Gets username.
     *
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * Sets username.
     *
     * @param username the username
     */
    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public String toString() {
        return "SubscribeTopicRequest{" +
                "topicName='" + topicName + '\'' +
                ", username='" + username + '\'' +
                '}';
    }
}
