package com.likemind.demo.constant;

/**
 * The type Command.
 */
public class Command {

    /**
     * The constant ADD_USER.
     */
    public static final String ADD_USER = "add_user";
    /**
     * The constant ADD_TOPIC.
     */
    public static final String ADD_TOPIC = "add_topic";
    /**
     * The constant SUBSCRIBE_TOPIC.
     */
    public static final String SUBSCRIBE_TOPIC = "subscribe_topic";

    public static final String ADD_MESSAGE ="add_message";
    /**
     * The constant PROCESS_MESSAGE.
     */
    public static final String PROCESS_MESSAGE = "process_message";

    public static final String END = "end";
}
